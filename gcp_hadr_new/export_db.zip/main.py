import os
import functions_framework
from googleapiclient.discovery import build
from google.auth import default

# Get environment variables
PROJECT_ID = os.getenv("GCP_PROJECT")
INSTANCE_ID = os.getenv("SQL_INSTANCE")
DATABASE_NAME = os.getenv("DB_NAME")
GCS_BUCKET = os.getenv("GCS_BUCKET")

@functions_framework.http
def export_db(request):
    """Trigger Cloud SQL export to Cloud Storage."""
    
    # Get credentials from Cloud Function's environment
    credentials, _ = default()
    service = build("sqladmin", "v1beta4", credentials=credentials)

    # Define export request body
    body = {
        "exportContext": {
            "fileType": "SQL",
            "uri": f"gs://{GCS_BUCKET}/{DATABASE_NAME}-backup.sql",
            "databases": [DATABASE_NAME]
        }
    }

    try:
        # Trigger the export
        request = service.instances().export(project=PROJECT_ID, instance=INSTANCE_ID, body=body)
        response = request.execute()
        return f"Export Triggered: {response}", 200
    except Exception as e:
        return f"Error triggering export: {str(e)}", 500