import os
import google.auth
from googleapiclient import discovery

PROJECT_ID = os.getenv("GCP_PROJECT")
INSTANCE_ID = os.getenv("SQL_INSTANCE")
DATABASE_NAME = os.getenv("DB_NAME")
GCS_BUCKET = os.getenv("GCS_BUCKET")

def export_db(event, context):
    credentials, _ = google.auth.default()
    service = discovery.build('sqladmin', 'v1beta4', credentials=credentials)

    body = {
        "exportContext": {
            "fileType": "SQL",
            "uri": f"gs://{GCS_BUCKET}/{DATABASE_NAME}-backup.sql",
            "databases": [DATABASE_NAME]
        }
    }

    request = service.instances().export(project=PROJECT_ID, instance=INSTANCE_ID, body=body)
    response = request.execute()
    print("Export Triggered:", response)